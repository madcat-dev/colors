#!/usr/bin/env bash

# Initialise
BASE="$(realpath `dirname "$0"`)"
colors=( )

while [ -n "$1" ]; do
    [[ ${1:0:1} == "#" ]] && \
        colors+=( "${1}" ) || \
        BRIGHT_VARIANT="${1}"
    shift
done

colors[0]=${colors[0]:-#202020}
colors[1]=${colors[1]:-${colors[0]}}
colors[2]=${colors[2]:-${colors[1]}}


if [[ ${BRIGHT_VARIANT} ]]; then
    BRIGHT_VARIANT="-dark"

    sed  -i "s/#565656/#aaaaaa/g" \
        "${BASE}"/{16,22,24}/actions/*.svg || exit 1

    sed  -i "s/#727272/#aaaaaa/g" \
        "${BASE}"/{16,22,24}/{places,devices}/*.svg || exit 1

    sed  -i "s/#555555/#aaaaaa/g" \
        "${BASE}"/symbolic/{actions,apps,categories,devices,emblems,emotes,mimetypes,places,status}/*.svg || \
        exit 1
fi


sed  -i "s/#5294E2/${colors[0]}/gi" \
    "${BASE}"/scalable/places/default-*.svg || exit 1

sed  -i "s/#66bcff/${colors[1]}/gi" \
    "${BASE}"/scalable/places/default-*.svg || exit 1

sed  -i "s/#b29aff/${colors[2]}/gi" \
    "${BASE}"/scalable/places/default-*.svg || exit 1

sed  -i "s/#5294E2/${colors[0]}/gi" \
    "${BASE}"/16/places/folder*.svg || exit 1
